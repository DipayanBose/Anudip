create database bank;
use bank;
Create table BankAccount (Account_ID INT PRIMARY KEY, Account_Holder_name varchar(50), Account_balance varchar(50));
select*from BankAccount;
INSERT INTO BankAccount
(Account_Id, Account_Holder_name, Account_balance)
VALUES
(101, 'Rahul Sen', 45000),
(102, 'Anita Sharma', 28000),
(103, 'Sourav Das', 65000);
SELECT Account_Holder_name, Account_balance
FROM BankAccount;
SELECT Account_Holder_name, Account_balance
FROM BankAccount
WHERE Account_balance > 30000;
UPDATE BankAccount
SET Account_balance = 50000
WHERE Account_Id = 101;


