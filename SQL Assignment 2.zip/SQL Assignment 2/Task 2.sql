Create database Office;
use Office;
CREATE TABLE EMP (EmployeeID INT PRIMARY KEY,FirstName VARCHAR(50),LastName VARCHAR(50),Department VARCHAR(50),Phone VARCHAR(15));
CREATE TABLE EmergencyContact (ContactID INT PRIMARY KEY,EmployeeID INT,ContactName VARCHAR(100),Relationship VARCHAR(50),ContactPhone VARCHAR(15),ContactAddress TEXT,FOREIGN KEY (EmployeeID) REFERENCES EMP(EmployeeID));
INSERT INTO EMP (EmployeeID, FirstName, LastName, Department, Phone) VALUES (1, 'Rahul', 'Sen', 'IT', '9876543210');
select * from EMP;
INSERT INTO EMP (EmployeeID, FirstName, LastName, Department, Phone) VALUES (4, 'Soutrik', 'Som', 'Data Engineer', '9474158656');
INSERT INTO EMP (EmployeeID, FirstName, LastName, Department, Phone) VALUES (5, 'Didhiti', 'Das', 'Data Engineer', '9474158656');

INSERT INTO EMP (EmployeeID, FirstName, LastName, Department, Phone) VALUES (2, 'Rahul', 'Sinha', 'IT', '8972753990');
INSERT INTO EMP (EmployeeID, FirstName, LastName, Department, Phone) VALUES (3, 'Dipayan', 'Bose', 'Data Analyst', '8436290670');
INSERT INTO EmergencyContact (ContactID, EmployeeID, ContactName, Relationship, ContactPhone, ContactAddress) VALUES(1, 2, 'Sita Sen', 'Wife', '9876501234', 'Kolkata, West Bengal');
