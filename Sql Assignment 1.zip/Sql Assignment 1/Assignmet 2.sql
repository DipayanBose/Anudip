Create database Office;
use Office;
CREATE TABLE EMP (EmployeeID INT PRIMARY KEY,FirstName VARCHAR(50),LastName VARCHAR(50),Department VARCHAR(50),Phone VARCHAR(15));
CREATE TABLE EmergencyContact (ContactID INT PRIMARY KEY,EmployeeID INT,ContactName VARCHAR(100),Relationship VARCHAR(50),ContactPhone VARCHAR(15),ContactAddress TEXT,FOREIGN KEY (EmployeeID) REFERENCES EMP(EmployeeID));
